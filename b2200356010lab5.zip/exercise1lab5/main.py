# Write a program that asks for a number N as a user input,
#and calculates the sum of odd numbers, and the average of even numbers starting from 1 up to and including N.
N = int(input("Please enter a number\n"))
sum_of_oddn = 0
sum_of_evenn = 0
avg_of_evenn = 0
how_many_even = 0
for i in range(1, N+1):
    if i % 2 == 1:
        sum_of_oddn += i
    elif i % 2 == 0:
        sum_of_evenn += i
        how_many_even += 1
        avg_of_evenn = sum_of_evenn // how_many_even
print(f"Sum of odd numbers from 1 to {N} is {sum_of_oddn}")
print(f"Average of even numbers from 1 to {N} is {avg_of_evenn}")
