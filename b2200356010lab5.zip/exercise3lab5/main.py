import random
a = random.randint(1, 101)
game_on = True
while game_on is True:
    b = int(input("Guess a number!"))
    if a == b:
        print("You found the number!!")
        game_on = False
    elif a > b:
        print("Higher")
    elif a < b:
        print("Lower")
