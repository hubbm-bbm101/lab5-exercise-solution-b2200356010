#Write a Boolean function that checks if a string contains ‘@’ sign and at least one ‘.’
# dot (disregard the order for the sake of simplicity). Use that function to check if a user input is
# a valid e-mail or not.
while True:
    email = input("Please enter your e-mail.\n")
    if "@" and "." in email:
        print("It's valid.")
    else:
        print("This email isn't valid.")

